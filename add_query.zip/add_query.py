# -*- coding: utf-8 -*-
import scipy.io
import csv
import pymysql

# Majors
conn = pymysql.connect(host='127.0.0.1', user='root', password='1234', db='graduate', charset='utf8')
curs = conn.cursor()
conn.commit()
f = open('Majors.csv','r',encoding = 'utf-8-sig')
csvReader = csv.reader(f)
for row in csvReader:    
    major_name = row[0]
    major_name = "\"" + major_name + "\""
    sql = "insert into graduate.majors (major_name) values (%s)" %(major_name)
    curs.execute(sql)
conn.commit()
f.close() 
conn.close()

# Check_field
conn = pymysql.connect(host='127.0.0.1', user='root', password='1234', db='graduate', charset='utf8')
curs = conn.cursor()
conn.commit()
f = open('Check_field.csv','r',encoding = 'utf-8-sig')
csvReader = csv.reader(f)
for row in csvReader:  
    major_no = int(row[0])
    student_id = int(row[1])
    check_field_name = row[2]
    check_field_name = "\"" + check_field_name + "\""
    course_id = int(row[1])
    check_field_number = int(row[3])
    check_field_credit = int(row[4])
    sql = "insert into graduate.check_field (major_no, student_id, check_field_name, check_field_number, check_field_credit) values(%d, %d, %s, %d, %d);" %(major_no, student_id, check_field_name, check_field_number, check_field_credit)
    curs.execute(sql)
conn.commit()
f.close() 
conn.close()

# Field
conn = pymysql.connect(host='127.0.0.1', user='root', password='1234', db='graduate', charset='utf8')
curs = conn.cursor()
conn.commit()
f = open('Field.csv','r',encoding = 'utf-8-sig')
csvReader = csv.reader(f)
for row in csvReader: 
    check_field_no = int(row[0])
    major_no = int(row[1])
    student_id = int(row[2])
    field_name = row[3]
    field_name = "\"" + field_name + "\""
    field_number = int(row[4])
    field_credit = int(row[5])
    sql = "insert into graduate.field (check_field_no, major_no, student_id, field_name, field_number, field_credit) values (%d, %d, %d, %s, %d, %d);" %(check_field_no, major_no, student_id, field_name, field_number, field_credit)
    curs.execute(sql)
conn.commit()
f.close() 
conn.close()

# Course
conn = pymysql.connect(host='127.0.0.1', user='root', password='1234', db='graduate', charset='utf8')
curs = conn.cursor()
conn.commit()
f = open('Course.csv','r',encoding = 'utf-8-sig')
csvReader = csv.reader(f)
for row in csvReader:    
    major_no = int(row[0])
    student_id = int(row[1])
    field_no = int(row[2])
    course_id = int(row[3])
    course_name = row[4]
    course_name = "\"" + course_name + "\""
    course_semester = int(row[6])
    course_hours = row[7]
    course_credit = int(row[8])
    pre_course_id = row[9]
    course_grade = row[5]
    if pre_course_id == "null":
        if course_grade == "null":
            if course_hours == "null":
                sql = "insert into graduate.course(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id) values (%d, %d, %d, %d, %s, null, %d, null, %d, null);" %(major_no, student_id,  field_no, course_id, course_name, course_semester, course_credit)
            else:
                course_hours = float(course_hours)
                sql = "insert into graduate.course(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id) values (%d, %d, %d, %d, %s, null, %d, %.2f, %d, null);" %(major_no, student_id,  field_no, course_id, course_name, course_semester, course_hours, course_credit)
        else:
            course_grade = int(course_grade)
            if course_hours == "null":
                sql = "insert into graduate.course(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id) values (%d, %d, %d, %d, %s, %d, %d, null, %d, null);" %(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_credit)
            else:
                course_hours = float(course_hours)
                sql = "insert into graduate.course(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id) values (%d, %d, %d, %d, %s, %d, %d, %.2f, %d, null);" %(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit)
    else:
        pre_course_id = int(pre_course_id)
        if course_grade == "null":
            if course_hours == "null":
                sql = "insert into graduate.course(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id) values (%d, %d, %d, %d, %s, null, %d, null, %d, %d);" %(major_no, student_id,  field_no, course_id, course_name, course_semester, course_credit, pre_course_id)
            else:
                course_hours = float(course_hours)
                sql = "insert into graduate.course(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id) values (%d, %d, %d, %d, %s, null, %d, %.2f, %d, %d);" %(major_no, student_id,  field_no, course_id, course_name, course_semester, course_hours, course_credit, pre_course_id)
        else:
            course_grade = int(course_grade)
            if course_hours == "null":
                sql = "insert into graduate.course(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id) values (%d, %d, %d, %d, %s, %d, %d, null, %d, %d);" %(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_credit, pre_course_id)
            else:
                course_hours = float(course_hours)
                sql = "insert into graduate.course(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id) values (%d, %d, %d, %d, %s, %d, %d, %.2f, %d, %d);" %(major_no, student_id,  field_no, course_id, course_name, course_grade, course_semester, course_hours, course_credit, pre_course_id)            
    curs.execute(sql)
conn.commit()
f.close() 
conn.close()

# Class
conn = pymysql.connect(host='127.0.0.1', user='root', password='1234', db='graduate', charset='utf8')
curs = conn.cursor()
conn.commit()
f = open('Class.csv','r',encoding = 'utf-8-sig')
csvReader = csv.reader(f)
for row in csvReader:    
    class_name = row[0]
    class_name = "\"" + class_name + "\""
    course_id = int(row[1])
    professor_name = row[2]
    professor_name = ''.join(professor_name.split())
    professor_name = "\"" + professor_name + "\""
    class_division = int(row[3])
    class_time = row[5]
    if class_time == "null":
        sql = "insert into graduate.class (class_name, course_id, professor_name, class_division, class_time) values (%s, %d, %s, %d, null)" %(class_name, course_id, professor_name, class_division)
    else:
        try:
            class_time = int(float(row[5]))
        except:
            print(row[5])
        sql = "insert into graduate.class (class_name, course_id, professor_name, class_division, class_time) values (%s, %d, %s, %d, %d)" %(class_name, course_id, professor_name, class_division, class_time)
    curs.execute(sql)
conn.commit()
f.close() 
conn.close()
