// 3단계로 추천: 학년&전공 => 필수교양&전공 => 교양
// 시간표에서 0일때 시간 제외한 것
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Timetable_maker {
	static int user_no = 2;
	static int major_no = 0;
	static String user_pre[] = new String[6];
	static ArrayList<Class_character> able_elective_class = new ArrayList<Class_character> ();
	static int out_time[][] = new int[5][7];
	static int first_class_check[] = new int[100];
	static int second_class_check[] = new int[100];
	static int third_class_check[] = new int[100];
	static int first_timetable_smallest_credit = 0;
	static int first_timetable_smallest_class_num = 0;
	static int second_timetable_smallest_credit = 0;
	static int second_timetable_smallest_class_num = 0;
	static int third_timetable_smallest_credit = 0;
	static int third_timetable_smallest_class_num = 0;
	static ArrayList<New_timetable> new_timetable_list = new ArrayList<New_timetable> ();
	static ArrayList<Class_character> first_able_class_list = new ArrayList<Class_character> ();
	static ArrayList<Class_character> second_able_class_list = new ArrayList<Class_character> ();
	static ArrayList<Class_character> third_able_class_list = new ArrayList<Class_character> ();
	
	public static void first_select(int v, int n) {
		int check_class_num = 0;
		for(int i = 0; i <= v; i ++) {
			check_class_num += first_class_check[i];
		}
		if(check_class_num > 8) {
			return;
		}
		else {
			if (v == n) {
				int credit = 0;
				int course_equal_check[] = new int[40000];
				int now_out_time[][] = new int[5][7];
				for(int i = 0; i < n; i++) {
					if(first_class_check[i] == 1) {
						Class_character now_class = first_able_class_list.get(i);
						int now_credit = now_class.class_credit;
						int now_time = now_class.class_time;
						int now_no = now_class.class_no;
						int now_course_id = now_class.course_id;
						
						// 1) 같은 학수번호 제거
						if(course_equal_check[now_course_id] == 1) {
							return;
						}
						course_equal_check[now_course_id] = 1;
						// 2) 시간 0인 수업 제거
						if(now_time == 0) {
							return;
						}
						// 3) 총학점 제거
						credit += now_credit;
						if(credit > 21 || credit < 3) {
							return;
						}
						// 4) 수업끼리 시간 겹치면 제거
						String now_time_str = Integer.toString(now_time);
						for(int j = 0; j < now_time_str.length(); j++) {
							int now_time_integer_first = Integer.parseInt(now_time_str.substring(0, 1))-1;
							int now_time_integer_second = Integer.parseInt(now_time_str.substring(1, 2))-1;
							if(now_out_time[now_time_integer_first][now_time_integer_second] == 1) {
								return;
							}else {
								now_out_time[now_time_integer_first][now_time_integer_second] = 1;
							}
							if (now_time_str.length() >= 2) {
								now_time_str = now_time_str.substring(2, now_time_str.length());
							}
						}
					}
				}
				// 여기까지 통과했으면 저장
				if(credit > 0) {
					String new_timetable_time = "";
					for(int i = 0; i < n; i++) {
						new_timetable_time  = new_timetable_time + Integer.toString(first_class_check[i]);
					}
					new_timetable_list.add(new New_timetable(now_out_time, credit, new_timetable_time));
				}
			}
			else {
				first_class_check[v] = 1;
				first_select(v+1, n);
				first_class_check[v] = 0;
				first_select(v+1, n);
			}
		}
	}
	
	public static void second_select(int v, int n) {
		int check_class_num = 0;
		for(int i = 0; i <= v; i ++) {
			check_class_num += second_class_check[i];
		}
		if(check_class_num + first_timetable_smallest_class_num > 9) {
			return;
		}
		else {
			if (v == n) {
				for(int aaaa = 0; aaaa < 5; aaaa ++) {
					New_timetable now_timetable = new_timetable_list.get(aaaa);
					int now_timetable_out_time[][] = now_timetable.timetable_out_time;
					int now_timetable_credit = now_timetable.credit;
					int course_equal_check[] = new int[40000];
					
					for(int i = 0; i < n; i++) {
						if(second_class_check[i] == 1) {
							Class_character now_class = second_able_class_list.get(i);
							int now_credit = now_class.class_credit;
							int now_time = now_class.class_time;
							int now_no = now_class.class_no;
							int now_course_id = now_class.course_id;
							
							// 1) 같은 학수번호 제거
							if(course_equal_check[now_course_id] == 1) {
								return;
							}
							course_equal_check[now_course_id] = 1;
							// 2) 시간 0인 수업 제거
							if(now_time == 0) {
								return;
							}
							// 3) 총학점 제거
							now_timetable_credit += now_credit;
							if(now_timetable_credit > 21 || now_timetable_credit < 3) {
								return;
							}
							// 4) 수업끼리 시간 겹치면 제거
							String now_time_str = Integer.toString(now_time);
							for(int j = 0; j < now_time_str.length(); j++) {
								int now_time_integer_first = Integer.parseInt(now_time_str.substring(0, 1))-1;
								int now_time_integer_second = Integer.parseInt(now_time_str.substring(1, 2))-1;
								if(now_timetable_out_time[now_time_integer_first][now_time_integer_second] == 1) {
									return;
								}else {
									now_timetable_out_time[now_time_integer_first][now_time_integer_second] = 1;
								}
								if (now_time_str.length() >= 2) {
									now_time_str = now_time_str.substring(2, now_time_str.length());
								}
							}
						}
					}
					// 여기까지 통과했으면 저장
					if(now_timetable_credit > 0) {
						String new_timetable_time = now_timetable.new_timetable;
						for(int i = 0; i < n; i++) {
							new_timetable_time  = new_timetable_time + Integer.toString(second_class_check[i]);
						}
						new_timetable_list.add(new New_timetable(now_timetable_out_time, now_timetable_credit, new_timetable_time));
					}
				}
			}else {
				second_class_check[v] = 1;
				second_select(v+1, n);
				second_class_check[v] = 0;
				second_select(v+1, n);
			}
		}
	}
	
	public static void third_select(int v, int n) {
		int check_class_num = 0;
		for(int i = 0; i <= v; i ++) {
			check_class_num += third_class_check[i];
		}
		if(check_class_num + second_timetable_smallest_class_num > 9) {
			return;
		}
		else {
			if (v == n) {
				for(int aaaa = 0; aaaa < 5; aaaa ++) {
					New_timetable now_timetable = new_timetable_list.get(aaaa);
					int now_timetable_out_time[][] = now_timetable.timetable_out_time;
					int now_timetable_credit = now_timetable.credit;
					int course_equal_check[] = new int[40000];
					
					for(int i = 0; i < n; i++) {
						if(third_class_check[i] == 1) {
							Class_character now_class = third_able_class_list.get(i);
							int now_credit = now_class.class_credit;
							int now_time = now_class.class_time;
							int now_no = now_class.class_no;
							int now_course_id = now_class.course_id;
							
							// 1) 같은 학수번호 제거
							if(course_equal_check[now_course_id] == 1) {
								return;
							}
							course_equal_check[now_course_id] = 1;
							// 2) 시간 0인 수업 제거
							if(now_time == 0) {
								return;
							}
							// 3) 총학점 제거
							now_timetable_credit += now_credit;
							if(now_timetable_credit > 21 || now_timetable_credit < 3) {
								return;
							}
							// 4) 수업끼리 시간 겹치면 제거
							String now_time_str = Integer.toString(now_time);
							for(int j = 0; j < now_time_str.length(); j++) {
								int now_time_integer_first = Integer.parseInt(now_time_str.substring(0, 1))-1;
								int now_time_integer_second = Integer.parseInt(now_time_str.substring(1, 2))-1;
								if(now_timetable_out_time[now_time_integer_first][now_time_integer_second] == 1) {
									return;
								}else {
									now_timetable_out_time[now_time_integer_first][now_time_integer_second] = 1;
								}
								if (now_time_str.length() >= 2) {
									now_time_str = now_time_str.substring(2, now_time_str.length());
								}
							}
						}
					}
					// 여기까지 통과했으면 저장
					if(now_timetable_credit > 0) {
						String new_timetable_time = now_timetable.new_timetable;
						for(int i = 0; i < n; i++) {
							new_timetable_time  = new_timetable_time + Integer.toString(third_class_check[i]);
						}
						new_timetable_list.add(new New_timetable(now_timetable_out_time, now_timetable_credit, new_timetable_time));
					}
				}
			}else {
				third_class_check[v] = 1;
				third_select(v+1, n);
				third_class_check[v] = 0;
				third_select(v+1, n);
			}
		}
	}
	
	public static void main(String[] args) {
		Connection conn = null;
		Statement state = null;
		ResultSet resset = null;
		ResultSet resset2 = null;
		ResultSet resset3 = null;
		ResultSet resset4 = null;
		ResultSet resset5 = null;
		ResultSet resset6 = null;
		ResultSet resset7 = null;
		ResultSet resset8 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		PreparedStatement pstmt3 = null;
		PreparedStatement pstmt4 = null;
		PreparedStatement pstmt5 = null;
		PreparedStatement pstmt6 = null;
		PreparedStatement pstmt7 = null;
		PreparedStatement pstmt8 = null;
		String url = "jdbc:mysql://localhost:3306/graduate?&serverTimezone=UTC";
		String sql = "";
		String sql2 = "";
		String sql3 = "";
		String sql4 = "";
		String sql5 = "";
		String sql6 = "";
		String sql7 = "";
		String sql8 = "";
		
 		try {
			// JDBC DB 연결
			conn = DriverManager.getConnection(url, "root", "1234");
			state = conn.createStatement();
			
			// 1. 사용자 전공 받기(major_no)
			sql = "select major_no from Majors, User where Majors.major_name = User.user_major and User.user_no = " + user_no;
			pstmt = conn.prepareStatement(sql);
			resset = state.executeQuery(sql);
			while(resset.next()) {
				major_no = resset.getInt("major_no");
			}resset.close();
			
			// 2. 사용자가 불가능한 시간 받기
			sql2 = "select * from User_time where user_no = " + user_no;
			pstmt2 = conn.prepareStatement(sql2);
			resset2 = state.executeQuery(sql2);
			while(resset2.next()) {
				String[] temp_time = new String[5];
				temp_time[0] = Integer.toString(resset2.getInt("time_mon"));
				temp_time[1] = Integer.toString(resset2.getInt("time_tue"));
				temp_time[2] = Integer.toString(resset2.getInt("time_wed"));
				temp_time[3] = Integer.toString(resset2.getInt("time_thr"));
				temp_time[4] = Integer.toString(resset2.getInt("time_fri"));
				
				for(int temp_time_index = 0; temp_time_index < 5; temp_time_index++) {
					int jjj = 6;
					for(int each_temp = (temp_time[temp_time_index].length()- 1); each_temp >= 0; each_temp--) {
						out_time[temp_time_index][jjj] = Integer.parseInt(temp_time[temp_time_index].substring(each_temp, each_temp+1));
						jjj--;
					}
				}
			}resset2.close();
			
			
			System.out.println("1. 사용자가 제외한 시간");
			for(int i = 0 ; i < 5; i++) {
				for (int j = 0; j < 7; j++) {
					System.out.printf("%d", out_time[i][j]);
				}
				System.out.println("");
			}
			
			// 3. 사용자가 들을 수 있는 과목 받기
			sql3 = "select distinct class.class_no, class.course_id, class.class_time, class.class_credit, min(field.check_field_no) as check_field_no from user_class, class, course, field where user_class.user_no = " + user_no + " and User_class.class_pre = False and User_class.class_next = True and user_class.class_no = class.class_no and class.course_id = course.course_id and course.field_no = field.field_no group by class.class_no";
			pstmt3 = conn.prepareStatement(sql3);
			resset3 = state.executeQuery(sql3);
			System.out.println("\n2. 사용자가 들을 수 있는 과목");
			while(resset3.next()) {
				int now_class_no = resset3.getInt("class_no");
				int now_course_id = resset3.getInt("course_id");
				int now_class_time = resset3.getInt("class_time");
				int now_class_credit = resset3.getInt("class_credit");
				int now_check_field_no = resset3.getInt("check_field_no");
				Class_character now_class = new Class_character(now_class_no, now_class_time, now_class_credit, now_course_id);
				
				// 과목의 시간이 사용자 선택 시간과 맞지 않으면 추가하지 않음
				if(now_class_time > 0) {
					String now_class_time_str = Integer.toString(now_class_time);
					for(int j = 0; j < now_class_time_str.length(); j++) {
						// out_time array는 0부터 시작하기 때문에 1 뺌
						int now_time_integer_first = Integer.parseInt(now_class_time_str.substring(0, 1))-1;
						int now_time_integer_second = Integer.parseInt(now_class_time_str.substring(1, 2))-1;
						if(out_time[now_time_integer_first][now_time_integer_second] == 0) {
							continue;
						}
						if (now_class_time_str.length() >= 2) {
							now_class_time_str = now_class_time_str.substring(2, now_class_time_str.length());
						}
					}
				}
				if(now_check_field_no == 7 || now_check_field_no == 8) {
					first_able_class_list.add(now_class);
				}else if(now_check_field_no == 1 || now_check_field_no == 2 || now_check_field_no == 3 || now_check_field_no == 4) {
					second_able_class_list.add(now_class);
				}else {
					third_able_class_list.add(now_class);
				}
				System.out.printf("%d %d %d %d %d\n", now_class_no, now_course_id, now_class_time, now_class_credit, now_check_field_no);
			}resset3.close();
			
			System.out.printf("\n3. first 가능한 과목 개수 : %d\n", first_able_class_list.size());
			first_select(0, first_able_class_list.size());
			Collections.sort(new_timetable_list);
			Collections.reverse(new_timetable_list);
			
			System.out.printf("size: %d\n", new_timetable_list.size());
			int len = new_timetable_list.size();
			if(len > 5) {
				for(int i = len-1; i >= 5; i--) {
					new_timetable_list.remove(i);
				}
			}
			System.out.printf("size: %d\n", new_timetable_list.size());
			System.out.println("======================first sorted===============");
			for(int i = 0; i < 5; i++) {
				New_timetable a = new_timetable_list.get(i);
				int now_credit = a.credit;
				String now_time = a.new_timetable;
				System.out.printf("%d %s\n", now_credit, now_time);
			}
			first_timetable_smallest_credit = new_timetable_list.get(4).credit;
			String[] first_timetable_smallest_class_num_list = new_timetable_list.get(4).new_timetable.split("");
			for(int i = 0; i < first_timetable_smallest_class_num_list.length; i++) {
				if(first_timetable_smallest_class_num_list[i].equals("1")) {
					first_timetable_smallest_class_num++;
				}
			}
			System.out.printf("smallest credit, class_num: %d, %d\n\n", first_timetable_smallest_credit, first_timetable_smallest_class_num);
			
			System.out.printf("\n4. second 가능한 과목 개수 : %d\n", second_able_class_list.size());
			second_select(0, second_able_class_list.size());
			Collections.sort(new_timetable_list);
			Collections.reverse(new_timetable_list);

			for(int i = 0; i < new_timetable_list.size(); i++) {
				New_timetable now_timetable = new_timetable_list.get(i);
				System.out.printf("%d %s\n", now_timetable.credit, now_timetable.new_timetable);
			}
			System.out.printf("size: %d\n", new_timetable_list.size());
			int len2 = new_timetable_list.size();
			if (len2 > 5) {
				for(int i = len2-1; i >= 5; i--) {
					new_timetable_list.remove(i);
				}
			}
			System.out.printf("size: %d\n", new_timetable_list.size());
			System.out.println("======================second sorted===============");
			for(int i = 0; i < 5; i++) {
				New_timetable a = new_timetable_list.get(i);
				int now_credit = a.credit;
				String now_time = a.new_timetable;
				System.out.printf("%d %s\n", now_credit, now_time);
			}
			second_timetable_smallest_credit = new_timetable_list.get(4).credit;
			String[] second_timetable_smallest_class_num_list = new_timetable_list.get(4).new_timetable.split("");
			for(int i = 0; i < second_timetable_smallest_class_num_list.length; i++) {
				if(second_timetable_smallest_class_num_list[i].equals("1")) {
					second_timetable_smallest_class_num++;
				}
			}
			System.out.printf("smallest credit, class_num: %d, %d\n\n", second_timetable_smallest_credit, second_timetable_smallest_class_num);
			
			
			
			System.out.printf("\n5. third 가능한 과목 개수 : %d\n", third_able_class_list.size());
			third_select(0, third_able_class_list.size());
			Collections.sort(new_timetable_list);
			Collections.reverse(new_timetable_list);

			for(int i = 0; i < new_timetable_list.size(); i++) {
				New_timetable now_timetable = new_timetable_list.get(i);
				System.out.printf("%d %s\n", now_timetable.credit, now_timetable.new_timetable);
			}
			System.out.printf("size: %d\n", new_timetable_list.size());
			int len3 = new_timetable_list.size();
			if (len3 > 5) {
				for(int i = len3-1; i >= 5; i--) {
					new_timetable_list.remove(i);
				}
			}
			System.out.printf("size: %d\n", new_timetable_list.size());
			System.out.println("======================third sorted===============");
			for(int i = 0; i < 5; i++) {
				New_timetable a = new_timetable_list.get(i);
				int now_credit = a.credit;
				String now_time = a.new_timetable;
				System.out.printf("%d %s\n", now_credit, now_time);
			}
			third_timetable_smallest_credit = new_timetable_list.get(4).credit;
			String[] third_timetable_smallest_class_num_list = new_timetable_list.get(4).new_timetable.split("");
			for(int i = 0; i < third_timetable_smallest_class_num_list.length; i++) {
				if(third_timetable_smallest_class_num_list[i].equals("1")) {
					third_timetable_smallest_class_num++;
				}
			}
			System.out.printf("smallest credit, class_num: %d, %d\n\n", third_timetable_smallest_credit, third_timetable_smallest_class_num);
			
			// 4. DB에 결과 저장
			int timetable_number = 1;
			int timetable_class_no[] = new int[first_able_class_list.size() + second_able_class_list.size() + third_able_class_list.size()];
			for (int i = 0; i < 5; i++) {
				New_timetable now_timetable_add = new_timetable_list.get(i);
				int credit = now_timetable_add.credit;		
				String new_timetable = now_timetable_add.new_timetable;
				for(int abc = 0; abc < first_able_class_list.size(); abc++) {
					timetable_class_no[abc] = first_able_class_list.get(abc).class_no;
				}
				for(int abc = 0; abc < second_able_class_list.size(); abc++) {
					timetable_class_no[abc+first_able_class_list.size()] = second_able_class_list.get(abc).class_no;
				}
				for(int abc = 0; abc < third_able_class_list.size(); abc++) {
					timetable_class_no[abc+first_able_class_list.size()+second_able_class_list.size()] = third_able_class_list.get(abc).class_no;
				}
				
				String[] now_timetable_list = new_timetable.split("");
				sql4 = "insert into graduate.user_timetable (user_no, class_1, class_2, class_3, class_4, class_5, class_6, class_7, class_8, class_9, credit) values(" + user_no + ", ?, ?, ?, ?, ?, ?, ?, ?, ?, " + credit + ");";
				pstmt4 = conn.prepareStatement(sql4);
				int class_num_check = 1;
				for (int k = 0; k < now_timetable_list.length; k++) {
					if(now_timetable_list[k].equals("1")) {					
						pstmt4.setInt(class_num_check, timetable_class_no[k]);
						class_num_check += 1;
					}
				}
				for (int k = class_num_check; k <= 9; k++) {
					pstmt4.setInt(class_num_check, -1);
					class_num_check += 1;
				}
				pstmt4.executeUpdate();
				System.out.println("DB ADD");
				timetable_number += 1;
			}	
			
			// 여기 부터 교양 추천
			sql5 = "select exam_pre, quiz_pre, presentation_pre, project_pre, assignment_pre, attendance_pre from User_preference where user_no = " + user_no;
			pstmt5 = conn.prepareStatement(sql5);
			resset5 = state.executeQuery(sql5);
			while(resset5.next()) {
				int exam_pre = resset5.getInt("exam_pre");
				user_pre[exam_pre-1] = "exam_per";
				int quiz_pre = resset5.getInt("quiz_pre");
				user_pre[quiz_pre-1] = "quiz_per";
				int presentation_pre = resset5.getInt("presentation_pre");
				user_pre[presentation_pre-1] = "presentation_per";
				int project_pre = resset5.getInt("project_pre");
				user_pre[project_pre-1] = "project_per";
				int assignment_pre = resset5.getInt("assignment_pre");
				user_pre[assignment_pre-1] = "assignment_per";
				int attendance_pre = resset5.getInt("attendance_pre");
				user_pre[attendance_pre-1] = "attendance_per";
			}resset5.close();
			
			sql6 = "select class_no, class_time, class_credit from Class_elective order by " + user_pre[0] + " desc, " + user_pre[1]+ " desc, " + user_pre[2] + " desc, " + user_pre[3] + " desc, " + user_pre[4] + " desc, " + user_pre[5] + " desc";
			pstmt6 = conn.prepareStatement(sql6);
			resset6 = state.executeQuery(sql6);
			int elective_class_num = 1;
			while(resset6.next()) {
				int new_class_no = resset6.getInt("class_no");
				int new_class_time = resset6.getInt("class_time");
				int new_class_credit = resset6.getInt("class_credit");
				Class_character new_elective_class = new Class_character(new_class_no, new_class_time, new_class_credit, -1);
				able_elective_class.add(new_elective_class);
				if(elective_class_num > 150) {
					break;
				}
				elective_class_num++;
			}resset6.close();
			
			for(int i = 0; i < 5; i++) {
				int final_elective_class[] = new int[5];
				New_timetable now_timetable = new_timetable_list.get(i);
				int now_timetable_out_time[][] = now_timetable.timetable_out_time;
				elective_class_num = 0;
				AA: for(int j = 0; j < 150; j++) {
					Class_character now_elective_class = able_elective_class.get(j);
					String now_elective_time = Integer.toString(now_elective_class.class_time);
					for(int aak = 0; aak < now_elective_time.length(); aak++) {
						int now_time_integer_first = Integer.parseInt(now_elective_time.substring(0, 1))-1;
						int now_time_integer_second = Integer.parseInt(now_elective_time.substring(1, 2))-1;
						if(now_timetable_out_time[now_time_integer_first][now_time_integer_second] == 1) {
							continue AA;
						}
						if (now_elective_time.length() >= 2) {
							now_elective_time = now_elective_time.substring(2, now_elective_time.length());
						}
					}
					System.out.printf("final_elective_class_add: %d\n", now_elective_class.class_no);
					final_elective_class[elective_class_num] = now_elective_class.class_no;
					elective_class_num++;
					if(elective_class_num > 4) break;
				}
				
				int class_num_check = 1;
				int now_timetable_class_no[] = new int[9];
				String now_timetable_list[] = now_timetable.new_timetable.split("");
				for (int k = 0; k < now_timetable_list.length; k++) {
					if(now_timetable_list[k].equals("1")) {					
						now_timetable_class_no[class_num_check-1] = timetable_class_no[k];
						class_num_check += 1;
					}
				}
				for (int k = class_num_check; k <= 9; k++) {
					now_timetable_class_no[class_num_check-1] = -1;
					class_num_check += 1;
				}
				
				int user_timetable_no = 0;
				sql7 = "select user_timetable_no from user_timetable where user_no = " + user_no + " and class_1 = " + now_timetable_class_no[0] + " and class_2 = " + now_timetable_class_no[1] +" and class_3 = " + now_timetable_class_no[2] + " and class_4 = " + now_timetable_class_no[3] +" and class_5 = " + now_timetable_class_no[4] + " and class_6 = " + now_timetable_class_no[5] + " and class_7 = " + now_timetable_class_no[6] + " and class_8 = " + now_timetable_class_no[7] + " and class_9 = " + now_timetable_class_no[8];
				pstmt7 = conn.prepareStatement(sql7);
				resset7 = state.executeQuery(sql7);
				while(resset7.next()) {
					user_timetable_no = resset7.getInt("user_timetable_no");
				}resset7.close();
				
				
				for (int kkk = 0; kkk < 5; kkk++) {	
					if(final_elective_class[kkk] != 0) {
						System.out.printf("\ntimetable_no: %d, elective_class_no: %d\n", user_timetable_no, final_elective_class[kkk]);
						sql8 = "insert into graduate.user_elective_timetable (timetable_number, class_no, user_no) values(" + user_timetable_no + ", ?, " + user_no + ");";
						pstmt8 = conn.prepareStatement(sql8);
						pstmt8.setInt(1, final_elective_class[kkk]);
						pstmt8.executeUpdate();
					}
				}
				System.out.println("DB ADD");
			}

		}catch(SQLException e) {
			System.out.print("error: " + e);
		}finally {
			if(resset != null) {
				try {
					pstmt.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(state != null) {
				try {
					state.close();
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn != null) {
				try {
					conn.close();
				} catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	}
}
